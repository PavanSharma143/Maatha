package org.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Update
 */
@WebServlet("/Reset")
public class Reset extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Reset() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String user = request.getParameter("username");
		String pass = request.getParameter("pass");
		String cpass = request.getParameter("Cpass");
		String Role = request.getParameter("role");
		Connection con;
		String email = null;
		String password = null;
		String conPassword = null;
		String person = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","admin");
			
			String sql ="update register set password='"+pass+"' , cpassword='"+cpass+"' , person='"+Role+"' where email='"+user+"'";
			
			PreparedStatement statement = con.prepareStatement(sql);
			
			ResultSet executeQuery = statement.executeQuery();
			
			while(executeQuery.next()) {
				email = executeQuery.getString("email");
				password = executeQuery.getString("password");
				conPassword = executeQuery.getString("cpassword");
				person = executeQuery.getString("person");
			}
			
			 
	          
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		
        
		System.out.println("Updated successfully");
		out.println("Updated succeefully now you can login");
		request.getRequestDispatcher("Login.jsp").forward(request, response);
		
		//boolean updateSuccessful = performUpdate();

//        if (executeQuery.next()=true) {
//            // Display a success message dialog
//            JOptionPane.showMessageDialog(null, "Update successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
//            request.getRequestDispatcher("Login.jsp").forward(request, response);
//        } else {
//            // Display an error message dialog if the update failed
//            JOptionPane.showMessageDialog(null, "Update failed. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
//            request.getRequestDispatcher("Reset.jsp").forward(request, response);
//        }
//    }
		
		  
//
//		
//		if(user.equals(email) && pass.equals(password) && Role.equals(person)) {
//			System.out.println("Successfully login");
//			request.setAttribute("user", user);
//			request.getRequestDispatcher("Success.jsp").forward(request, response);
//			
//		}
//		else {
//			System.out.println("WRONG CRREDENTIALS");
//			request.getRequestDispatcher("Reset.jsp").forward(request, response);
//		}
	}

}
