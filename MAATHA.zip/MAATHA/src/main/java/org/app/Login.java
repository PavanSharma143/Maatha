package org.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter out = response.getWriter();
		
		String user = request.getParameter("username");
		String pass = request.getParameter("pass");
		String Role = request.getParameter("role");
		Connection con;
		String email = null;
		String password = null;
		String person = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","admin");
			
			String sql ="select * from register where email='"+user+"' and password='"+pass+"' and person='"+Role+"'";
			
			PreparedStatement statement = con.prepareStatement(sql);
			
			ResultSet executeQuery = statement.executeQuery();
			
			while(executeQuery.next()) {
				email = executeQuery.getString("email");
				password = executeQuery.getString("password");
				person = executeQuery.getString("person");
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		  
	   	
//	System.out.println("Registered successfully");
//	out.println("Registered successfully now you can login");
//	//request.getRequestDispatcher("login.jsp").forward(request, response);
//}
//
//}
		
		if(user.equals(email) && pass.equals(password) && Role.equals("User")) {
			System.out.println("Successfully login");
			
			response.setContentType("text/html");
			 out.println("<script type=\"text/javascript\">");
	         out.println("alert('Login Success now you can see your profile ');");
	         out.println("location='Success.jsp';");
	         out.println("</script>");
	         request.setAttribute("username", user);
	         request.getRequestDispatcher("Success.jsp").forward(request, response);
	            
		}
		else if(user.equals(email) && pass.equals(password) && Role.equals("Doctor")) {
			System.out.println("Successfully login");
			
			response.setContentType("text/html");
			 out.println("<script type=\"text/javascript\">");
	         out.println("alert('Login Success now you can see your profile ');");
	         out.println("location='DSuccess.jsp';");
	         out.println("</script>");
	         request.setAttribute("username", user);
	         request.getRequestDispatcher("Dsuccess.jsp").forward(request, response);
	            
		}
		else {
			System.out.println("WRONG CRREDENTIALS");
			response.setContentType("text/html");
           
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Wrong Credentials you can Reset these');");
            out.println("location='Reset.jsp';");
            out.println("</script>");
	    }
	}
}