package org.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String Fname = request.getParameter("fname");
		System.out.println("First name is: "+Fname);
		
		String Lname = request.getParameter("lname");
		System.out.println("Last name is: "+Lname);
		
		String Email = request.getParameter("email");
		System.out.println("Email is: "+Email);
		
		
		String Phone = request.getParameter("phone");
		System.out.println("Phone number is: "+Phone);
	
		
		String Pass = request.getParameter("pass");
		System.out.println("Password is: "+Pass);
		
		
		String Cpass = request.getParameter("cpass");
		System.out.println("Confirm password is: "+Cpass);
		
		
		String gender = request.getParameter("gender");
		System.out.println("Gender is : "+gender);
		
		
		String person = request.getParameter("person");
		System.out.println("person is : "+person);
		
		
		Connection con = null; 
			//step1 load the driver class  
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");

				
				con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","admin");
				
				String sql ="insert into register(firstname,lastname,email,phone,password,cpassword,gender,person) values (?,?,?,?,?,?,?,?)";
				
				PreparedStatement statement = con.prepareStatement(sql);
				
				statement.setString(1, Fname);
				statement.setString(2, Lname);
				statement.setString(3, Email);
				statement.setString(4, Phone);
				statement.setString(5, Pass);
				statement.setString(6, Cpass);
				statement.setString(7, gender);
				statement.setString(8, person);
				
				
				statement.executeUpdate();
				
				con.close();
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
			  
		   	
			System.out.println("Registered successfully");
			//out.println("Registered successfully now you can login");
			response.setContentType("text/html");
			out.println("<script type=\"text/javascript\">");
	        out.println("alert('Thank you for Registering , Successfully Registered');");
	        out.println("location='Login.jsp';");
	        out.println("</script>");
			//request.getRequestDispatcher("Login.jsp").forward(request, response);
		}

	}