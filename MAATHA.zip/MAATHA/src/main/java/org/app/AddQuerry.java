package org.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddQuerry
 */
@WebServlet("/AddQuerry")
public class AddQuerry extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddQuerry() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String Type = request.getParameter("Querry");
		
		
		String Area = request.getParameter("area");
		
		Connection con = null; 
		//step1 load the driver class  
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","admin");
			
			String sql ="insert into userdata(Type,Area) values (?,?)";
			
			PreparedStatement statement = con.prepareStatement(sql);
			
			statement.setString(1, Type);
			statement.setString(2, Area);
			
			statement.executeUpdate();
			
			con.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		response.setContentType("text/html");
		out.println("<script type=\"text/javascript\">");
        out.println("alert('Thank you for Adding querry successfully');");
        out.println("location='Success.jsp';");
        out.println("</script>");
	}

}
